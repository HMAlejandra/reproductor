# MusicApp - Aplicación de Música con Spotify

Una aplicación web moderna conectada con la API de Spotify que te permite explorar, buscar y disfrutar de tu música favorita.

## Características

- 🎵 Autenticación con Spotify OAuth
- 🏠 Página de inicio con música reciente y top tracks
- 🔍 Búsqueda de canciones, artistas y álbumes
- 📚 Biblioteca personal con playlists y canciones guardadas
- ⚙️ Página de ajustes con información de cuenta
- 🎨 Diseño moderno y responsivo inspirado en Spotify

## Requisitos

- Python 3.8+
- Cuenta de Spotify Developer
- Cuenta de Render (para despliegue)

## Configuración Local

1. **Clona el repositorio**
\`\`\`bash
git clone <tu-repositorio>
cd spotify-music-app
\`\`\`

2. **Crea un entorno virtual**
\`\`\`bash
python -m venv venv
source venv/bin/activate  # En Windows: venv\Scripts\activate
\`\`\`

3. **Instala las dependencias**
\`\`\`bash
pip install -r requirements.txt
\`\`\`

4. **Configura las credenciales de Spotify**

Ve a [Spotify Developer Dashboard](https://developer.spotify.com/dashboard) y:
- Crea una nueva aplicación
- Obtén tu Client ID y Client Secret
- Agrega `http://127.0.0.1:5000/callback` a las Redirect URIs

5. **Configura las variables de entorno**

Crea un archivo `.env` en la raíz del proyecto:
\`\`\`
SECRET_KEY=tu_clave_secreta_super_segura
SPOTIFY_CLIENT_ID=tu_client_id_de_spotify
SPOTIFY_CLIENT_SECRET=tu_client_secret_de_spotify
SPOTIFY_REDIRECT_URI=http://127.0.0.1:5000/callback
\`\`\`

6. **Ejecuta la aplicación**
\`\`\`bash
python app.py
\`\`\`

Visita `http://127.0.0.1:5000` en tu navegador.

## Despliegue en Render

1. **Crea una cuenta en [Render](https://render.com)**

2. **Crea un nuevo Web Service**
   - Conecta tu repositorio de GitHub
   - Selecciona Python como entorno
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`

3. **Configura las variables de entorno en Render**
   - `SECRET_KEY`: Una clave secreta segura
   - `SPOTIFY_CLIENT_ID`: Tu Client ID de Spotify
   - `SPOTIFY_CLIENT_SECRET`: Tu Client Secret de Spotify
   - `SPOTIFY_REDIRECT_URI`: `https://tu-app.onrender.com/callback`

4. **Actualiza la Redirect URI en Spotify Developer Dashboard**
   - Agrega `https://tu-app.onrender.com/callback` a las Redirect URIs

5. **Despliega la aplicación**
   - Render automáticamente construirá y desplegará tu aplicación

## Estructura del Proyecto

\`\`\`
spotify-music-app/
├── app.py                 # Aplicación Flask principal
├── requirements.txt       # Dependencias de Python
├── README.md             # Este archivo
├── .gitignore            # Archivos ignorados por Git
├── static/
│   └── style.css         # Estilos CSS
└── templates/
    ├── login.html        # Página de login
    ├── index.html        # Página principal
    ├── search.html       # Página de búsqueda
    ├── library.html      # Página de biblioteca
    └── settings.html     # Página de ajustes
\`\`\`

## Tecnologías Utilizadas

- **Backend**: Flask (Python)
- **API**: Spotify Web API (Spotipy)
- **Frontend**: HTML5, CSS3
- **Despliegue**: Render
- **Servidor**: Gunicorn

## Funcionalidades de la API de Spotify

- Autenticación OAuth 2.0
- Obtener información del usuario
- Canciones reproducidas recientemente
- Top tracks del usuario
- Búsqueda de música
- Biblioteca personal (playlists y canciones guardadas)

## Licencia

MIT License - Siéntete libre de usar este proyecto para tus propios fines.

## Soporte

Si tienes problemas o preguntas, abre un issue en el repositorio.
