from flask import Flask, render_template, redirect, url_for, session, request, jsonify
import spotipy
from spotipy.oauth2 import SpotifyOAuth
import os
from datetime import datetime

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv no es requerido en producción

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "tu_clave_secreta_super_segura_cambiar_en_produccion")
app.config["SESSION_COOKIE_NAME"] = "spotify-music-session"

# Configuración de Spotify desde variables de entorno
CLIENT_ID = os.environ.get("SPOTIFY_CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("SPOTIFY_CLIENT_SECRET", "")
REDIRECT_URI = os.environ.get("SPOTIFY_REDIRECT_URI", "http://127.0.0.1:5000/callback")
SCOPE = "user-read-playback-state user-modify-playback-state user-read-currently-playing user-library-read user-top-read playlist-read-private"

if not CLIENT_ID or not CLIENT_SECRET:
    print("⚠️  ADVERTENCIA: SPOTIFY_CLIENT_ID o SPOTIFY_CLIENT_SECRET no están configurados")
    print("Por favor, configura las variables de entorno. Ver CONFIGURACION_LOCAL.md")

sp_oauth = SpotifyOAuth(
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    redirect_uri=REDIRECT_URI,
    scope=SCOPE,
    cache_path=None
)

def get_token():
    """Obtiene y refresca el token de acceso de Spotify"""
    token_info = session.get("token_info", None)
    if not token_info:
        return None
    
    if sp_oauth.is_token_expired(token_info):
        token_info = sp_oauth.refresh_access_token(token_info["refresh_token"])
        session["token_info"] = token_info
    
    return token_info

def get_spotify_client():
    """Crea un cliente de Spotify autenticado"""
    token_info = get_token()
    if not token_info:
        return None
    return spotipy.Spotify(auth=token_info["access_token"])

@app.route("/")
def home():
    """Página de inicio/login"""
    if get_token():
        return redirect(url_for("index"))
    return render_template("login.html")

@app.route("/login")
def login():
    """Inicia el flujo de autenticación de Spotify"""
    auth_url = sp_oauth.get_authorize_url()
    return redirect(auth_url)

@app.route("/callback")
def callback():
    """Callback de autenticación de Spotify"""
    session.clear()
    code = request.args.get("code")
    token_info = sp_oauth.get_access_token(code)
    session["token_info"] = token_info
    return redirect(url_for("index"))

@app.route("/logout")
def logout():
    """Cierra la sesión del usuario"""
    session.clear()
    return redirect(url_for("home"))

@app.route("/index")
def index():
    """Página principal con recomendaciones"""
    sp = get_spotify_client()
    if not sp:
        return redirect(url_for("home"))
    
    try:
        user = sp.current_user()
        recently_played = sp.current_user_recently_played(limit=6)
        top_tracks = sp.current_user_top_tracks(limit=6, time_range="short_term")
        
        recent_tracks = []
        for item in recently_played["items"]:
            track = item["track"]
            recent_tracks.append({
                "name": track["name"],
                "artist": track["artists"][0]["name"],
                "image": track["album"]["images"][0]["url"] if track["album"]["images"] else None,
                "uri": track["uri"],
                "url": track["external_urls"]["spotify"]
            })
        
        top_tracks_list = []
        for track in top_tracks["items"]:
            top_tracks_list.append({
                "name": track["name"],
                "artist": track["artists"][0]["name"],
                "image": track["album"]["images"][0]["url"] if track["album"]["images"] else None,
                "uri": track["uri"],
                "url": track["external_urls"]["spotify"]
            })
        
        return render_template("index.html", 
                             user=user, 
                             recent_tracks=recent_tracks,
                             top_tracks=top_tracks_list)
    except Exception as e:
        print(f"Error: {e}")
        return redirect(url_for("logout"))

@app.route("/search")
def search():
    """Página de búsqueda"""
    sp = get_spotify_client()
    if not sp:
        return redirect(url_for("home"))
    
    query = request.args.get("q", "")
    results = []
    
    if query:
        try:
            search_results = sp.search(q=query, limit=20, type="track")
            for track in search_results["tracks"]["items"]:
                results.append({
                    "name": track["name"],
                    "artist": track["artists"][0]["name"],
                    "album": track["album"]["name"],
                    "image": track["album"]["images"][0]["url"] if track["album"]["images"] else None,
                    "uri": track["uri"],
                    "url": track["external_urls"]["spotify"]
                })
        except Exception as e:
            print(f"Error en búsqueda: {e}")
    
    user = sp.current_user()
    return render_template("search.html", user=user, results=results, query=query)

@app.route("/library")
def library():
    """Página de biblioteca del usuario"""
    sp = get_spotify_client()
    if not sp:
        return redirect(url_for("home"))
    
    try:
        user = sp.current_user()
        saved_tracks = sp.current_user_saved_tracks(limit=50)
        playlists = sp.current_user_playlists(limit=20)
        
        tracks = []
        for item in saved_tracks["items"]:
            track = item["track"]
            tracks.append({
                "name": track["name"],
                "artist": track["artists"][0]["name"],
                "album": track["album"]["name"],
                "image": track["album"]["images"][0]["url"] if track["album"]["images"] else None,
                "uri": track["uri"],
                "url": track["external_urls"]["spotify"],
                "added_at": item["added_at"]
            })
        
        user_playlists = []
        for playlist in playlists["items"]:
            user_playlists.append({
                "name": playlist["name"],
                "tracks": playlist["tracks"]["total"],
                "image": playlist["images"][0]["url"] if playlist["images"] else None,
                "url": playlist["external_urls"]["spotify"]
            })
        
        return render_template("library.html", 
                             user=user, 
                             tracks=tracks,
                             playlists=user_playlists)
    except Exception as e:
        print(f"Error: {e}")
        return redirect(url_for("logout"))

@app.route("/settings")
def settings():
    """Página de ajustes"""
    sp = get_spotify_client()
    if not sp:
        return redirect(url_for("home"))
    
    user = sp.current_user()
    return render_template("settings.html", user=user)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
