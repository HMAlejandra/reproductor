# Guía de Despliegue en Render - ACTUALIZADA

## Problema Común: "Salió con el estado 1"

Si ves este error, es porque Render está intentando usar Docker en lugar de Python. Esta guía te ayudará a solucionarlo.

## Paso 1: Configurar Spotify Developer Dashboard

1. Ve a [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
2. Inicia sesión con tu cuenta de Spotify
3. Haz clic en **"Create app"**
4. Completa el formulario:
   - **App name**: "Mi App de Música"
   - **App description**: "Aplicación web para explorar música"
   - **Redirect URI**: `https://tu-app.onrender.com/callback` (cambiarás esto después)
   - Marca las casillas de términos y condiciones
5. Haz clic en **"Save"**
6. En la página de tu aplicación, haz clic en **"Settings"**
7. Copia y guarda:
   - **Client ID**
   - **Client Secret** (haz clic en "View client secret")

## Paso 2: Subir el código a GitHub

### Si ya tienes el repositorio en GitHub:

1. Asegúrate de que el archivo `render.yaml` esté en la raíz del proyecto
2. Haz commit y push de los cambios:

\`\`\`bash
git add .
git commit -m "Agregar configuración de Render"
git push origin main
\`\`\`

### Si aún no has subido el código:

1. Descarga el código de v0 (botón de tres puntos → Download ZIP)
2. Extrae el ZIP en una carpeta
3. Abre GitHub Desktop o usa la terminal:

\`\`\`bash
cd ruta/a/tu/proyecto
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/tu-usuario/tu-repositorio.git
git push -u origin main
\`\`\`

## Paso 3: Configurar Render CORRECTAMENTE

### Opción A: Usando render.yaml (RECOMENDADO)

1. Ve a [Render Dashboard](https://dashboard.render.com/)
2. Haz clic en **"New +"** → **"Blueprint"**
3. Conecta tu repositorio de GitHub
4. Render detectará automáticamente el archivo `render.yaml`
5. Haz clic en **"Apply"**

### Opción B: Configuración Manual

1. Ve a [Render Dashboard](https://dashboard.render.com/)
2. Haz clic en **"New +"** → **"Web Service"**
3. Conecta tu repositorio de GitHub
4. **IMPORTANTE**: Configura estos valores EXACTAMENTE así:

   - **Name**: `reproductor` (o el nombre que prefieras)
   - **Region**: selecciona la más cercana
   - **Branch**: `main`
   - **Root Directory**: (déjalo VACÍO)
   - **Runtime**: **Python 3** (NO selecciones Docker)
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app`
   - **Plan**: Free

5. En **"Environment Variables"**, agrega:

   \`\`\`
   SECRET_KEY = [genera una clave aleatoria segura]
   SPOTIFY_CLIENT_ID = [tu Client ID de Spotify]
   SPOTIFY_CLIENT_SECRET = [tu Client Secret de Spotify]
   SPOTIFY_REDIRECT_URI = https://tu-app.onrender.com/callback
   \`\`\`

   **IMPORTANTE**: Reemplaza `tu-app` con el nombre exacto que elegiste en el paso 4.

6. Haz clic en **"Create Web Service"**

## Paso 4: Verificar el Despliegue

1. Render comenzará a construir tu aplicación
2. Espera 5-10 minutos (el plan gratuito puede tardar más)
3. Verás los logs en tiempo real
4. Cuando veas "Starting gunicorn", tu app está lista
5. Haz clic en la URL en la parte superior (ej: `https://reproductor-4ahm.onrender.com`)

## Paso 5: Actualizar Redirect URI en Spotify

1. Vuelve al [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
2. Selecciona tu aplicación
3. Haz clic en **"Settings"**
4. En **"Redirect URIs"**, haz clic en **"Edit"**
5. Agrega la URL de tu aplicación en Render: `https://tu-app.onrender.com/callback`
6. Haz clic en **"Add"** y luego en **"Save"**

## Solución de Problemas

### Error: "Salió con el estado 1 mientras creaba su código"

**Causa**: Render está intentando usar Docker en lugar de Python.

**Solución**:
1. Ve a tu servicio en Render
2. Haz clic en **"Settings"** (en el menú lateral)
3. Busca la sección **"Build & Deploy"**
4. Verifica que:
   - **Runtime** sea **Python 3** (NO Docker)
   - **Build Command** sea `pip install -r requirements.txt`
   - **Start Command** sea `gunicorn app:app`
5. Si algo está mal, corrígelo y haz clic en **"Save Changes"**
6. Ve a **"Manual Deploy"** → **"Deploy latest commit"**

### Error: "INVALID_CLIENT: Invalid redirect URI"

**Causa**: La URL de redirección no coincide.

**Solución**:
1. Verifica que en Spotify Developer Dashboard la Redirect URI sea exactamente: `https://tu-app.onrender.com/callback`
2. Verifica que la variable de entorno `SPOTIFY_REDIRECT_URI` en Render sea exactamente la misma
3. Asegúrate de usar `https://` (no `http://`)

### Error: Variables de entorno no encontradas

**Causa**: Las variables de entorno no están configuradas en Render.

**Solución**:
1. Ve a tu servicio en Render
2. Haz clic en **"Environment"** (en el menú lateral)
3. Verifica que todas las variables estén configuradas:
   - `SECRET_KEY`
   - `SPOTIFY_CLIENT_ID`
   - `SPOTIFY_CLIENT_SECRET`
   - `SPOTIFY_REDIRECT_URI`
4. Si falta alguna, agrégala y haz clic en **"Save Changes"**

### La aplicación se queda "Building" por mucho tiempo

**Causa**: El plan gratuito de Render puede tardar más en desplegar.

**Solución**:
- Espera pacientemente (puede tardar hasta 15 minutos)
- Revisa los logs para ver el progreso
- Si después de 20 minutos sigue igual, cancela y vuelve a desplegar

### Error: "Application failed to respond"

**Causa**: La aplicación no se está iniciando correctamente.

**Solución**:
1. Revisa los logs en Render
2. Busca mensajes de error específicos
3. Verifica que todas las dependencias estén en `requirements.txt`
4. Asegúrate de que el comando de inicio sea `gunicorn app:app`

## Verificación Final

Para verificar que todo funciona:

1. Abre tu aplicación en Render: `https://tu-app.onrender.com`
2. Deberías ver la página de login
3. Haz clic en "Iniciar sesión con Spotify"
4. Autoriza la aplicación
5. Deberías ser redirigido a la página principal con tu música

Si todo funciona, ¡felicidades! Tu aplicación está desplegada correctamente.

## Notas Importantes

- El plan gratuito de Render pone tu aplicación en "sleep" después de 15 minutos de inactividad
- La primera carga después del "sleep" puede tardar 30-60 segundos
- Para mantener tu aplicación activa 24/7, necesitarías actualizar a un plan de pago
