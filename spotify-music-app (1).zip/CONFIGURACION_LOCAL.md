# Configuración para desarrollo local

## Paso 1: Crear aplicación en Spotify Developer Dashboard

1. Ve a [Spotify Developer Dashboard](https://developer.spotify.com/dashboard)
2. Inicia sesión con tu cuenta de Spotify
3. Haz clic en **"Create app"**
4. Completa el formulario:
   - **App name**: "Mi App de Música"
   - **App description**: "Aplicación web para explorar música"
   - **Website**: `http://127.0.0.1:5000`
   - **Redirect URI**: `http://127.0.0.1:5000/callback` ⚠️ **IMPORTANTE: Usa 127.0.0.1, NO localhost**
   - Marca las casillas de términos y condiciones
5. Haz clic en **"Save"**
6. En la página de tu aplicación, haz clic en **"Settings"**
7. Copia y guarda:
   - **Client ID**
   - **Client Secret** (haz clic en "View client secret")

## Paso 2: Configurar variables de entorno locales

### Opción A: Crear archivo .env (recomendado)

1. Crea un archivo llamado `.env` en la raíz del proyecto
2. Agrega las siguientes líneas (reemplaza con tus valores):

\`\`\`
SECRET_KEY=tu_clave_secreta_aleatoria_aqui
SPOTIFY_CLIENT_ID=tu_client_id_aqui
SPOTIFY_CLIENT_SECRET=tu_client_secret_aqui
SPOTIFY_REDIRECT_URI=http://127.0.0.1:5000/callback
\`\`\`

3. Instala python-dotenv:
\`\`\`bash
pip install python-dotenv
\`\`\`

### Opción B: Configurar en tu sistema (Windows)

Abre PowerShell y ejecuta:

```powershell
$env:SPOTIFY_CLIENT_ID="tu_client_id_aqui"
$env:SPOTIFY_CLIENT_SECRET="tu_client_secret_aqui"
$env:SPOTIFY_REDIRECT_URI="http://127.0.0.1:5000/callback"
$env:SECRET_KEY="tu_clave_secreta_aqui"
